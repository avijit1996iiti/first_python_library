class Substraction:
    def substract_two_numbers(self,num1 : float, num2 : float)->float:
        """ 
        This function takes two numbers as input and returns the substraction of second one from the first one
        """
        return num1 - num2