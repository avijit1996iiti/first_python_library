# first_python_library
A simple calcualtor