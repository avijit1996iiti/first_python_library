from addition import Addition
from substraction import Substraction
from multiplication import Multiplication
from division import Division

class Calculator(Addition,Substraction,Multiplication,Division):
    """
    This is an empty class created to inherit all required operations
    """
    pass

