class Multiplication:
    def multiply_two_numbers(self,num1 : float, num2 : float)->float:
        """ 
        This function takes two numbers as input and returns the multiplication of second one with the first one
        """
        return num1 * num2