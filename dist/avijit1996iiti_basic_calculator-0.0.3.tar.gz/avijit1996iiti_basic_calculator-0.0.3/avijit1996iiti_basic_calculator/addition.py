class Addition:

    def add_two_numbers(self,num1 : float, num2 : float)->float:
        """ 
        This function takes two numbers as input and returns the sum of them 
        """
        return num1 + num2