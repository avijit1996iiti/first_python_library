from avijit1996iiti_basic_calculator.addition import Addition

add = Addition()
print(add.add_two_numbers(8,9))